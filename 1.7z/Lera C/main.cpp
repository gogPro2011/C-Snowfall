#include <glfw3.h>
#include <stdlib.h>
#include <iostream>
#include <Windows.h>
#include <ctime>
#include <fstream>
#include <string>
#include <vector>
#define HIGHT 10
#define WIDTH 10

using namespace std;

int xPos = 0; //��������� ��������� ��������
int yPos = 0;

vector <string> recs;
clock_t timer;

int amount_for_solve;

typedef struct {
    bool contain_box;
    bool target; 
} Yaschik;

Yaschik map[HIGHT][WIDTH];

void StartNewGame() {
    amount_for_solve = 0;
    timer = clock();
    srand(time(NULL));
    for (int i = 0; i <= rand() % 7 + 2; i++) {
        int x = rand() % HIGHT;
        int y = rand() % WIDTH;

        if (!map[x][y].contain_box && !map[x][y].target) {
            map[x][y].target = true;
            while (true) {
                int b = rand() % HIGHT;
                int c = rand() % WIDTH;
                if (b > 0 && b < HIGHT - 1 && c > 0 && c < WIDTH - 1 && !map[b][c].target && !map[b][c].contain_box) {
                    map[b][c].contain_box = true;
                    amount_for_solve++;
                    break;
                }
            }
        }
        else {
            i--;
            continue;
        }
    }
}
void get_recs() {
    ifstream in("C:\\1\\recs.txt");
    string line;
    if (in.is_open())
    {
        for (int i = 0; i < 10; i++) {
            getline(in, line);
            //line.pop_back();
            recs.push_back(line);
        }
    }
    in.close();
}
bool is_time_rec() {
    int max_delta = 0;
    int max_delta_pos;
    for (int i = 0; i < 10; i++) {
        if (stoi(recs[i]) > timer) { 
            if (stoi(recs[i]) - timer > max_delta) {
                max_delta = stoi(recs[i]) - timer;
                max_delta_pos = i;
            }
            else continue;
        }
    }
    if (max_delta > 0) {
        recs[max_delta_pos] = to_string(timer);
        cout << "new rec" << endl;
        return true;
    }
    return false;
}
void new_rec_zap() {
    ofstream out("C:\\1\\recs.txt");
    if (out.is_open())
    {
        for(int i = 0; i < 10; i++)
            out << recs[i] << std::endl;
    }
}
void print_rec() {
    for (int i = 0; i < 10; i++) {
        cout << (double)stoi(recs[i]) / 1000 << endl;
    }
}
void GameEnd(bool p) {
    for (int i = 0; i < WIDTH; i++) {
        for (int j = 0; j < HIGHT; j++) {
            map[i][j].target = false;
            map[i][j].contain_box = false;
        }
    }
    double t = (double)(clock() - timer) / CLOCKS_PER_SEC;
    timer = clock() - timer;
    if (p && is_time_rec()) new_rec_zap();
    cout << "time elapsed:" << t << "\n\n" << endl;
    StartNewGame();
}
bool CheckGameEnd() {
    int k = 0;
    for (int i = 0; i < HIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (map[i][j].target && map[i][j].contain_box)
                k++;
        }
    }
    if (k == amount_for_solve) return true;
    else return false;
}
void TargetCross() {
    glVertex2f(1.0, 0.0);
    glVertex2f(0.0, 1.0);

    glVertex2f(1.0, 1.0);
    glVertex2f(0.0, 0.0);
}

void ShowCell(int x, int y) {
    glBegin(GL_LINES);
    glColor3f(0.0, 0, 1);
    glVertex2f(1.0, 0.0); glVertex2f(1.0, 1.0);
    glVertex2f(0.0, 1.0); glVertex2f(1.0, 1.0);
    glColor3f(1.0, 1.0, 0.0);
    glEnd();
    if(map[x][y].contain_box) {//������ ����
        glBegin(GL_QUADS);
        glColor3f(0.5, 0.3, 0.3);
        glVertex2f(0.0, 0.0);
        glVertex2f(1.0, 0.0);
        glVertex2f(1.0, 1.0);
        glVertex2f(0.0, 1.0);
        glEnd();
    }
    if (map[x][y].target) {//��� �������� ����
        glBegin(GL_LINES);
        glColor3f(1, 0.3, 0.3);
        TargetCross();
        glEnd();
    }
}
void ShowPlayer() {
    glBegin(GL_LINE_LOOP);
    glColor3f(0.0, 1.0, 0.0);
    glVertex2f(0.0, 0.0);
    glVertex2f(1.0, 0.0);
    glVertex2f(1.0, 1.0);
    glVertex2f(0.0, 1.0);
    glEnd();
}

void Game() {
    glLoadIdentity();
    glScalef(2.0 / HIGHT, 2.0 / WIDTH, 1.0);
    glTranslatef(-HIGHT * 0.5, -WIDTH * 0.5, 0.0);

    for (int i = 0; i < WIDTH; i++) {
        for (int j = 0; j < HIGHT; j++) {
            glPushMatrix();

            glTranslatef((float)i, (float)j, 0);
            
            if (i == xPos && j == yPos) {
                ShowPlayer();
            }
            else ShowCell(i, j);
            
            if (CheckGameEnd()) {
                cout << "WIN" << endl;
                GameEnd(true);
            }
            glPopMatrix();
        }
    }
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode) {
    if ((key == GLFW_KEY_A || key == GLFW_KEY_LEFT) && action == GLFW_PRESS) {
        if (xPos != 0) {
            if (map[xPos - 1][yPos].contain_box) {
                if (xPos - 2 >= 0 && !map[xPos - 2][yPos].contain_box) {
                    map[xPos - 1][yPos].contain_box = false;
                    map[xPos - 2][yPos].contain_box = true;
                    xPos--;
                }
            }
            else xPos--;
        }
    }
    else if ((key == GLFW_KEY_S || key == GLFW_KEY_DOWN) && action == GLFW_PRESS) {
        if (yPos != 0) {
            if (map[xPos][yPos - 1].contain_box) {
                if (yPos - 2 >= 0 && !map[xPos][yPos - 2].contain_box) {
                    map[xPos][yPos - 1].contain_box = false;
                    map[xPos][yPos - 2].contain_box = true;
                    yPos--;
                }
            }
            else yPos--;
        }
    }
    else if ((key == GLFW_KEY_W || key == GLFW_KEY_UP) && action == GLFW_PRESS) {
        if (yPos != HIGHT - 1) {
            if (map[xPos][yPos + 1].contain_box) {
                if (yPos + 2 <= HIGHT - 1 && !map[xPos][yPos + 2].contain_box) {
                    map[xPos][yPos + 1].contain_box = false;
                    map[xPos][yPos + 2].contain_box = true;
                    yPos++;
                }
            }
            else yPos++;
        }
    }
    else if ((key == GLFW_KEY_D || key == GLFW_KEY_RIGHT) && action == GLFW_PRESS) {
        if (xPos != WIDTH - 1) {
            if (map[xPos + 1][yPos].contain_box) {
                if (xPos + 2 <= WIDTH - 1 && !map[xPos + 2][yPos].contain_box) {
                    map[xPos + 1][yPos].contain_box = false;
                    map[xPos + 2][yPos].contain_box = true;
                    xPos++;
                }
            }
            else xPos++;
        }
    }
    else if (key == GLFW_KEY_Q && action == GLFW_PRESS) {
        cout << "LOSS" << endl;
        GameEnd(false);
    }
}

int main(void) {
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    if (!glfwInit())
        return -1;
    cout << "������ �������� �����\n�������� ����� �� ����� ���������" << endl;
    getchar();
    GLFWwindow* window = glfwCreateWindow(600, 600, "GAYME", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }
    get_recs();
    cout << "������� �������:" << endl;
    print_rec();
    glfwMakeContextCurrent(window);
    StartNewGame();
    glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

    while (!glfwWindowShouldClose(window))
    {
        glClear(GL_COLOR_BUFFER_BIT);

        Game();

        glfwSetKeyCallback(window, key_callback);

        glfwSwapBuffers(window);

        glfwPollEvents();
    }
    glfwTerminate();
}